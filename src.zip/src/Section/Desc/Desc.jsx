import React from "react";
import "./Desc.css";
import Desc2 from "../Desc2/Desc2";

export const Desc = () => {
  return (
    <>
      <div className="desc">
        <h1>Fighting hunger this holiday</h1>
        <p>
          Hunger is affecting millions of people across America this holiday
          season. Join us in our commitment to hunger relief and help feed
          neighbors in need.
        </p>
        <button className="btn btn">
          {" "}
          Get Involved <i class="fa fa-arrow-right" aria-hidden="true"></i>
        </button>
      </div>
      <Desc2 />
    </>
  );
};
export default Desc;
