import React from "react";
import "./Desc2.css";
import image from "../assets/120.webp";

export const Desc2 = () => {
  return (
    <div className="desc2">
       <div className="card mb-3">
        <div className="row g-0">
          <div className="col-md-6">
            <img src={image} className="img-fluid rounded-start" alt="home" />
          </div>
          <div className="col-md-6 right-side">
            <div className="card-body">
              <h4 className="card-title">
                Earning 4,500 Bonus Stars is Super Starifying
              </h4>
              <p className="card-text">
                Earn more Stars and even more Rewards with a $0 intro annual fee
                for your first year with the Starbucks® Rewards Visa® Card. Plus
                your Stars won’t expire – an exclusive Starbucks benefit for
                cardmembers. Now that’s Super Starifying.
              </p>
              <div className="buttons">
              <button className="btn btn" > Learn More</button>
              </div>
            </div>
          </div>
        </div>
      </div> 
      <hr />
    </div>
  );
};

export default Desc2;
