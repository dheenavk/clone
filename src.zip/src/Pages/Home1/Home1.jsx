import React from "react";
import "./Home1.css";
import image from "../assets/one.jpg";

export const Home1 = () => {
  return (
    <>
      <div>
        <div className="home1">
          <div className="card mb-3">
            <div className="row g-0">
              <div className="col-md-7 left-side">
                <img
                  src={image}
                  className="img-fluid rounded-start"
                  alt="hom"
                />
              </div>
              <div className="col-md-5">
                <div className="card-body right-side">
                  <h1 className="card-title">CHILL AND BE MERRY</h1>
                  <p className="card-text p">
                    Our Irish Cream Cold Brew is dressed up for the holidays
                    with sweet cream cold foam and a strike of cocoa.
                  </p>
                  <button className="btn btn">
                    Order Now{" "}  
                    <i class="fa fa-arrow-right" aria-hidden="true"></i>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Home1;
