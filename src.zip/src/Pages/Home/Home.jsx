import React from 'react'
import './Home.css'

export const Home = () => {
    return (
        <>
        <div className="home">
            <div className="container">
            <h1>JINGLE ALL THE WAY TO FREE FAVORITES</h1>    
            <p>Join Starbucks® Rewards for delicious deals & exclusive offers.</p>
            </div>
        </div>
        </>
    )
}
export default Home;