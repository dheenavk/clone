import React from "react";
import image from '../assets/back-img.jpg'
import "./Home2.css";

export const Home2 = () => {
  return (
    <div className="home2">
      <div class="card bg-dark text-white">
        <img src={image} class="card-img" alt="background-images" />
        <div class="card-img-overlay detail">
          <h1 class="card-title">MERRY MOMENT</h1>
          <p class="card-text">
          Treat yourself to a festive Sugar Plum Cheese Danish with a nicely spiced sugar-plum spread.
          </p>
          <button className="btn btn">Order Now   <i class="fa fa-arrow-right" aria-hidden="true"></i></button>
        </div>
      </div>
    </div>
  );
};

export default Home2;
