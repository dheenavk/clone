import "./App.css";
import Navbar from './Component/Navbar/Navbar'
import {BrowserRouter as Router, Switch, Route}from 'react-router-dom'
import Home from "./Pages/Home/Home";
import Home2 from "./Pages/Home2/Home2";
import Home1 from "./Pages/Home1/Home1";
import Desc from "./Section/Desc/Desc";
import Aboutus from "./List/Aboutus/Aboutus";

function App() {

  return (
    <Router>
    <div className="App">
      <Navbar />
      <Home />
      <Home1 />
      <Home2 />
      <Desc />
      <Aboutus />
    </div>
    </Router>
  );
}

export default App;
