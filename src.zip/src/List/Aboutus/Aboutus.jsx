import React from "react";
import "./Aboutus.css";
import Copyright from "../Copyright/Copyright";

export const Aboutus = () => {
  return (
    <div className="list ">
      <div className="row">
        <div className="col-2">
          <div className="about">
            <h5>About Us</h5>
            <ul>
              <li>Our Company</li>
              <li> Our Coffee</li>
              <li>Stories and News</li>
              <li>Starbucks Archive</li>
              <li>Investor Relations</li>
              <li>Customer Service</li>
            </ul>
          </div>
        </div>
        <div className="col-3">
          <div className="careers">
            <h5>Careers</h5>
            <ul>
              <li> Culture and Values </li>
              <li> Inclusion, Diversity, and Equity </li>
              <li> College Achievement Plan </li>
              <li> Alumni Community</li>
              <li> U.S. Careers </li>
              <li>International Careers</li>
            </ul>
          </div>
        </div>
        <div className="col-2">
          <div className="social">
            <h5>Social Impact</h5>
            <ul>
              <li> People </li>
              <li> Planet </li>
              <li> Environmental and Social Impact Reporting</li>
            </ul>
          </div>
        </div>
        <div className="col-2">
          <div className="buissness">
            <h5>Buissness Partner</h5>
            <ul>
              <li> Landlord Support Center</li>
              <li> Suppliers </li>
              <li> Corporate Gift Card Sales </li>
              <li> Office and Foodservice Coffee </li>
            </ul>
          </div>
        </div>
        <div className="col-3">
          <div className="order">
            <h5> Order and Pickup</h5>
            <ul>
              <li> Order on the App </li>
              <li> Order on the App </li>
              <li> Delivery </li>
              <li> Order and Pickup Options </li>
              <li> Explore and Find Coffee for Home </li>
            </ul>
          </div>
        </div>
      </div>
      <hr />
      <Copyright />
    </div>
  );
};
export default Aboutus;
