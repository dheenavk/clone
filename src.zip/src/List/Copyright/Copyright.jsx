import React from 'react'
import './Copyright.css'
export const Copyright = () => {
    return (
        <div className="copy">
            <div className="fonts container" >
                <div className="row font">
                    <div className="c-1"><a href=""><i class="fa fa-spotify" aria-hidden="true"></i></a></div>
                    <div className="c-2"><a href=""><i class="fa fa-facebook" aria-hidden="true"></i></a></div>
                    <div className="c-3"><a href=""><i class="fa fa-pinterest-square" aria-hidden="true"></i></a></div>
                    <div className="c-4"><a href=""><i class="fa fa-instagram" aria-hidden="true"></i></a></div>
                    <div className="c-5"><a href=""><i class="fa fa-youtube-play" aria-hidden="true"></i></a></div>
                    <div className="c-6"><a href=""><i class="fa fa-twitter" aria-hidden="true"></i></a></div>
                    <div className="c-7"><a href=""><i class="fa fa-twitch" aria-hidden="true"></i></a></div>
                </div>
            </div>
            <div className="about container">
                <div className="row">
                    <div className="col-2"> Privacy Policy         |</div>
                    <div className="col-2"> Terms of Use             | </div>
                    <div className="col-2"> CA Supply Chain Act      | </div>
                    <div className="col-2"> Cookie Preferences     | </div>
                </div>
            </div>
            <div className="container one">© 2021 Starbucks Coffee Company. All rights reserved.</div>
        </div>
    )
}

export default Copyright;