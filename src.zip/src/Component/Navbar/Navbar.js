import React from "react";
import './Navbar.css'
import logo from '../assets/logoo.png'

export const Navbar = () => {
  return (
    <div>
      <nav className="navbar navbar-expand-lg navbar-light bg-light ">
        <div className="container">
          <a className="navbar-brand fs-bold fs-4" id="header">
            <img src={logo} alt="logo" className="logo"/>
          </a>
          <button
            className="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span class="navbar-toggler-icon"></span>
          </button>
          <div className="collapse navbar-collapse" id="navbarSupportedContent">
            <ul className="navbar-nav mx-auto mb-3 mb-lg-0">
            <li className="nav-item">
                <a className="nav-link ">
                  Menu
                </a>
              </li>
              <li className="nav-item">
                <a className="nav-link" >
                  Rewords
                </a>
              </li>
              <li className="nav-item">
                <a className="nav-link" >
                  Gift Cards
                </a>
              </li>
            </ul>
            <div className="buttons">
            <button className="btn btn"><a>
            <i className="fa fa-map-marker" id="font" aria-hidden="true"></i> Find a Store 
            </a> </button>
          </div>
          </div>
        </div>
      </nav>
    </div>
  );
};
export default Navbar;
